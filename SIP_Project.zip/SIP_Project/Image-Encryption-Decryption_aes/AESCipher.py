
import base64
import hashlib
from Crypto import Random
from Crypto.Cipher import AES
import time
import sys
import os
import psutil
from PIL import Image


class AESCipher(object):

    def __init__(self, key):
        self.bs = 32
        self.key = hashlib.sha256(key.encode()).digest()

    # function to get memory usage of the system
    def memory_usage(self):
        process = psutil.Process(os.getpid())
        mem_info = process.memory_info()
        return mem_info.rss

    def encrypt(self, raw):
        start_time = time.time()
        raw = self._pad(raw)
        iv = Random.new().read(AES.block_size)
        cipher = AES.new(self.key, AES.MODE_CBC, iv)
        end_time = time.time()
        elapsed_time = end_time - start_time
        memory_used = self.memory_usage()
        print("Encryption (Stage-2) time: {:.5f} s".format(elapsed_time),"Memory usage in encrypting image: {:.3f} MB".format(memory_used / 1024 / 1024))
        return base64.b64encode(iv + cipher.encrypt(raw))

    def decrypt(self, enc):
        start_time = time.time()
        enc = base64.b64decode(enc)
        iv = enc[:AES.block_size]
        cipher = AES.new(self.key, AES.MODE_CBC, iv)
        end_time = time.time()
        elapsed_time = end_time - start_time
        memory_used = self.memory_usage()
        print("Decryption (Stage-2) time: {:.5f} s".format(elapsed_time), "Memory usage in decrypting image: {:.3f} MB".format(memory_used / 1024 / 1024))
        return self._unpad(cipher.decrypt(enc[AES.block_size:])).decode('utf-8')
        #return self._unpad(cipher.decrypt(enc[AES.block_size:])).decode('utf-8')

    def _pad(self, s):
        #print("25")
        #print(type(s))
        #print(type((self.bs - len(s) % self.bs) * chr(self.bs - len(s) % self.bs)))
        return s + (self.bs - len(s) % self.bs) * chr(self.bs - len(s) % self.bs).encode('utf-8')

    @staticmethod
    def _unpad(s):
        return s[:-ord(s[len(s)-1:])]


