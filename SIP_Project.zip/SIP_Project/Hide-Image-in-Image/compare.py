import cv2
import numpy as np
from skimage.metrics import structural_similarity as ssim

def psnr(img1, img2):
    mse = np.mean((img1 - img2) ** 2)
    if mse == 0:
        return 100
    PIXEL_MAX = 255.0
    return 20 * np.log10(PIXEL_MAX / np.sqrt(mse))

# Load the original and decrypted images
original_image = cv2.imread('img/lena.png') #Actual data
decrypted_image = cv2.imread('img/decoded_img.png')  #Decrypted img file
 # Get the dimensions of the image
#height, width, channels = decrypted_image.shape
#print(height+width+channels)
# Calculate SSIM index
ssim_index = ssim(original_image, decrypted_image,channel_axis=2)

print(f"SSIM index: {ssim_index}")
'''
1027
SSIM index: 0.7660049131724791
MSE: 0.25626373291015625
PSNR: 54.043932127853964
'''
# Calculate MSE
mse = np.mean((original_image - decrypted_image) ** 2)

print(f"MSE: {mse}")

# Calculate the PSNR
psnr_value = psnr(original_image, decrypted_image)
print('PSNR:', psnr_value)
